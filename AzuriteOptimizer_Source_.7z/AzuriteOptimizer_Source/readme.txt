Leaked by sudo#7939
Leaked by sudo#7939
Leaked by sudo#7939
Leaked by sudo#7939
Leaked by sudo#7939
Leaked by sudo#7939
Leaked by sudo#7939
Leaked by sudo#7939
Leaked by sudo#7939
Leaked by sudo#7939
Leaked by sudo#7939
Leaked by sudo#7939


To get normal code use Unminify & Deobfuscator ( if it's even obfuscated )


How to use?
Open cmd and write: cd C:\Users\%username%\Desktop\AzuriteOptimizer_Source

After this you need write 
npm install 

When it's done write
npm start 


